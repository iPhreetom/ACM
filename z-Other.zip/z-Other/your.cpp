#include <iostream>
#include <string>
#include <map>
#include <set>
#include <stack>
#include <algorithm>
#include <vector>
#include <queue>

#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cmath>
using namespace std;
#define LL long long
#define row(a, s, e) for(int a = s; a <= e; ++a)
#define wor(a, s, e) for(int a = s; a >= e; --a)
#define rowd(a, s, e, d) for(int a = s; a <= e; a += d)
#define max(a, b) ((a) > (b) ? (a) : (b))
#define min(a, b) ((a) < (b) ? (a) : (b))
#define MOD (1000000007)
//#define endl '\n'
#define int long long
typedef long long ll;
const int N = 1e5 + 7;
const int M = 1e9 + 7;

ll cnt;
ll fac[N] = {1, 1}, inv[N] = {1, 1}, f[N] = {1, 1};
ll C (ll a, ll b){
    if(b > a) return 0;
    return fac[a] * inv[b] % M * inv[a - b] % M;
}
ll A (ll a, ll b){
	if(b > a) return 0;
	return fac[a] * inv[a - b] % M;
}
void init2(){            //快速计算阶乘的逆元

    for(int i = 2; i < N; i ++){
        fac[i] = fac[i - 1] * i % M;
        f[i] = (M - M / i) * f[M % i] % M;
        inv[i] = inv[i - 1] * f[i] % M;
    }

}


int mod = 1e9+7;
int l, n2;
struct test{
	int first, second;
	test * next;
}*mp[112345], pool[1123456];
//vector<vector<pair<int,int> > > mp(112345);
bool book[112345];
long long son[112345];
long long ans = 0, pooll;

int dfs(int n, int l){
	book[n]=1;
	son[n]=1;
	//for(pair<int,int> v : mp[n]){
	for(test *v = mp[n]; v != NULL; v = v->next){
		if(book[v->first]==0){
			son[n]+=dfs(v->first, v->second);
		}
	}
	int tmp = son[n] * (n2 - son[n]) % M;
	tmp = tmp * l % M;
	ans = (ans + tmp ) %M;
	return son[n];
}

/*void dfsans(int index){
	book[index]=1;
	for(auto v : mp[index]){
		if(book[v.first]==0){
			long long left = n - son[index] + 1;
			long long right = son[v.first];
			ans += (((left*right)%mod)*v.second)%mod;
			ans %= mod;
			dfsans(v.first);
		}
	}
}
*/
void init(){
	memset(son,0,sizeof(son));
	memset(book,0,sizeof(book));
	//for (int i=0; i<mp.size(); i++){
	//	mp[i].clear();
	//}
	ans=0;
	pooll = 0;
	row(i, 0, 112340)
	    mp[i] = NULL;
}



signed main ()
{
    init2();
    //ll ans;
    int n, u, v;
    while(cin >> n)
    {
		init();
        n2 = n;
		//cin>>n;
		for(int i=1;i<n;i++){
			cin>>u>>v>>l;
			test *tmp = &pool[pooll++];
			tmp->first = u;
			tmp->second = l;
			tmp->next = mp[v];
			mp[v] = tmp;
			//mp[v].push_back(make_pair(u,l));
			tmp = &pool[pooll++];
			tmp->first = v;
			tmp->second = l;
			tmp->next = mp[u];
			mp[u] = tmp;
			//mp[u].push_back(make_pair(v,l));
		}
		dfs(1, 0);
		//memset(book,0,sizeof(book));
		//dfsans(1);
		//cout << ans << endl;
		ans = ans * (n - 1) % M;
		ans = ans * fac[n - 2] % M;
		ans = ans * 2 % M;
		cout << ans % M<< endl;
	}
    return 0;
}
