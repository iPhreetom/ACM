#include <bits/stdc++.h>
#define int long long
using namespace std;
#define random(a, b) ((a) + rand() % ((b) - (a) + 1))

stringstream ss;

signed main(int argc, char *argv[]) {
    // freopen("data.in","w",stdout);
    int seed = time(NULL);
    if (argc > 1) //如果有参数
    {
        ss.clear();
        ss << argv[1];
        ss >> seed; //把参数转换成整数赋值给seed
    }
    srand(seed);

    int n = random(10000,10000);
    cout<<n<<endl;
    // n = 20;

    set<int> a;
    set<int> b;
    a.insert(1);
    for (int i=2; i<=n; i++){
        b.insert(i);
    }

    for (int i=0; i<n-1; i++){
        int at = random(1,100000);
        at %= a.size();
        int cnt = 0;
        int l;
        for(auto i:a){
            l = i;
            if(cnt == at)break;
            cnt++;
        }

        int bt = random(1,100000);
        bt %= b.size();
        int r;
        cnt=0;
        for(auto i:b){
            r = i;
            if(cnt == bt)break;
            cnt++;
        }
        b.erase(r);
        a.insert(r);
        cout<<l<<' '<<r<<' '<<random(1,1000000000)<<endl;
    }

    return 0;
}
