// fyt
#include<bits/stdc++.h>
using namespace std;

int Double(int x){
	return x*2;
}
double Double(double x){
	return x*2;
}
float Double(float x){
	return x*2;
}
long Double(long x){
	return x*2;
}

int main(){

	return 0;
}
