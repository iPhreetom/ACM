// fyt
#include<bits/stdc++.h>
using namespace std;

class Rectangle{
private:
public:
	int itsLength;
	int itsWidth;
	Rectangle();
	Rectangle(int width, int length):itsLength(length),itsWidth(width){}
	~Rectangle();
};
int main(){

	return 0;
}
